#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components"

ditto "Motion Space.vst3" \
  "$HOME/Library/Audio/Plug-Ins/VST3/Motion Space.vst3"

ditto "Motion Space.component" \
  "$HOME/Library/Audio/Plug-Ins/Components/Motion Space.component"

echo "Orbit FX installed. Restart your DAW."
echo "Find it under ShevtoneAudio > Motion Space."
read -r -p "Press Enter to close..."
