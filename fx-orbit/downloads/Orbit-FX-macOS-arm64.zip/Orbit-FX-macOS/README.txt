ORBIT FX — macOS preview build

Close your DAW before installing.

Install manually:
- Copy Motion Space.vst3 to:
  ~/Library/Audio/Plug-Ins/VST3/
- Copy Motion Space.component to:
  ~/Library/Audio/Plug-Ins/Components/

Alternatively, run Install.command.
Restart your DAW and find:
ShevtoneAudio > Motion Space

Formats: AU and VST3. AAX is not included.
This preview is not notarized by Apple.
